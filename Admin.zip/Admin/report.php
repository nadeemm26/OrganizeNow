<link rel="stylesheet" href="table.css">
<?php include "connection.php"; include "admin_sidebar.php"; ?>

<h1>Generate Reports</h1>
<p>Filter User, Merchant, Booking, and Payment data by date and table selection.</p>

<!-- Report Filter Form -->
<form id="reportForm">
    <label>Select Table:</label>
    <select id="table_name" name="table_name" required>
        <option value="">-- Select Table --</option>
        <option value="user">User</option>
        <option value="merchant">Merchant</option>
        <option value="bookings">Booking</option>
        <option value="payments">Payment</option>
    </select>

    <label>From Date:</label>
    <input type="date" id="from_date" name="from_date" required>

    <label>To Date:</label>
    <input type="date" id="to_date" name="to_date" required>

    <button type="submit">Generate Report</button>
</form>

<!-- Report Section -->
<div id="report-section" style="display: none;">
    <h3>Report Data</h3>
    <button id="close-report" style="float: right; background-color: red; color: white; border: none; padding: 5px 10px; cursor: pointer;">Close</button>
    <button id="download-pdf" style="background-color: green; color: white; border: none; padding: 5px 10px; cursor: pointer;">Download PDF</button>
    <div id="report-content">Select a table and date range to generate a report.</div>
</div>

<!-- jQuery for AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function(){
        $("#reportForm").submit(function(e){
            e.preventDefault(); // Prevent page reload

            var table_name = $("#table_name").val();
            var from_date = $("#from_date").val();
            var to_date = $("#to_date").val();

            if (table_name == "") {
                alert("Please select a table.");
                return;
            }

            $.ajax({
                url: "fetch_report.php",
                type: "POST",
                data: { table_name: table_name, from_date: from_date, to_date: to_date },
                success: function(response){
                    $("#report-content").html(response);
                    $("#report-section").show();
                }
            });
        });

        // Close button functionality
        $("#close-report").click(function(){
            $("#report-section").hide();
        });

        // PDF Download Button
        $("#download-pdf").click(function(){
            var table_name = $("#table_name").val();
            var from_date = $("#from_date").val();
            var to_date = $("#to_date").val();

            if (table_name == "") {
                alert("Please select a table.");
                return;
            }

            window.location.href = "generate_pdf.php?table_name=" + table_name + "&from_date=" + from_date + "&to_date=" + to_date;
        });
    });
</script>
</body>
</html>
